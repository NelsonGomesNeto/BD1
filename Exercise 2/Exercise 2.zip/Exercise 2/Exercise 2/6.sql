select a.*
from ambulatorio a
where a.andar = 4 and (a.capacidade = 50 or a.numeroA > 10)